const styles = {
  addIcon: {
    paddingLeft: '8px',
    marginBottom: '-53px',
    fontSize: '34px',
    cursor: 'pointer',
    zIndex: '2',
    position: 'relative'
  }
};

export default styles;
