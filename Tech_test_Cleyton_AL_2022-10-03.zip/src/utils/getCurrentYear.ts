const getCurrentYear = () => new Date().getFullYear();

export default getCurrentYear;
