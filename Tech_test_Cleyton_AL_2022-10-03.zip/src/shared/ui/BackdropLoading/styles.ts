import colors from '@/helpers/theme/colors';

const styles = {
  zIndex: 999,
  backdropFilter: colors.loading.blur,
  background: colors.loading.background
};

export default styles;
