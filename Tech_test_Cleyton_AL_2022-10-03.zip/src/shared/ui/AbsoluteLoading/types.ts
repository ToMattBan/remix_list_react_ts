import { CircularProgressProps } from '@mui/material';

export interface IProps {
  size?: number;
  color?: CircularProgressProps['color'];
}
